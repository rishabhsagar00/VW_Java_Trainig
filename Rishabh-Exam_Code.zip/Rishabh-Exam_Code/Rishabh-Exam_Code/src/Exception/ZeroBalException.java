package Exception;



public class ZeroBalException extends Exception {
    
    @Override
    public String toString()
    {
        return "Sorry, You have Zero Balance in Your Account!";
    }
    
}