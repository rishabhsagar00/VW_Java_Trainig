package Exception;



public class InsufficientBalException extends Exception {
    
    @Override
    public String toString() {
    
        return "InsufficientBalException: You have insufficient Balance in your account";
    }
}