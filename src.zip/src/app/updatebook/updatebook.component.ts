import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BookdaoService } from '../bookdao.service';
import { Book } from '../model/book';

@Component({
  selector: 'app-updatebook',
  templateUrl: './updatebook.component.html',
  styleUrls: ['./updatebook.component.css']
})
export class UpdatebookComponent implements OnInit {
  bookId: Number;
  book: Book;
  bookdao: BookdaoService;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    bookdao: BookdaoService) {
    this.bookId = 0;
    this.book = new Book(0, '', '');
    this.bookdao = bookdao;
  }

  ngOnInit(): void {

    this.route

      .queryParams

      .subscribe(params => {

        console.log(params); // { order: "popular" }

        this.bookId = params['bookId'];

        console.log(this.bookId); // popular

      }

      );

    this.bookdao.getBookById(this.bookId).subscribe(

      (data: Book) => {

        console.log(data);

        this.book = data;

      }

    );

  }

  updateBook(form: any) {
    this.bookdao.updateBook(this.bookId, this.book).subscribe({
      complete: () => { console.log('updateBook put completed..') }, // completeHandler
      error: (error) => { console.log(error) },    // errorHandler
      next: (response) => { console.log('book updated successfully') }
    });

    this.router.navigate(['/listBooks']);
  }

}
