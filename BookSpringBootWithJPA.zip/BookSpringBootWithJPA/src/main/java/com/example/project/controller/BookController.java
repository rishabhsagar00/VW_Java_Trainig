package com.example.project.controller;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.project.entity.Book;
import com.example.project.repository.BookRepository;

import jakarta.transaction.Transactional;

//@CrossOrigin(origins = "http://localhost:4200/")
@CrossOrigin(origins = "*")
@RestController
public class BookController {
	@Autowired
	BookRepository bookRepository;

	@GetMapping("book1/{bookId}")
	public ResponseEntity<Book> getBookById(@PathVariable("bookId") int bookId) {
		Optional<Book> book = bookRepository.findByBookId(bookId);
		if (book.isPresent()) {
			return ResponseEntity.ok(book.get());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@GetMapping("bookName/{bookName}")
	public ResponseEntity<Book> getBookByBookName(@PathVariable("bookName") String bookName) {
		Optional<Book> book = bookRepository.findByBookName(bookName);
		if (book.isPresent()) {
			return ResponseEntity.ok(book.get());
		} else {
			return ResponseEntity.notFound().build();
		}
	}

	@PostMapping("addBook1")
	public ResponseEntity<Book> createBook(@RequestBody Book book) {
		try {
			Book _book = bookRepository.save(new Book(book.getBookId(), book.getBookName(), book.getBookAuthor()));
			URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/book/{id}")
					.buildAndExpand(_book.getBookId()).toUri();
			return ResponseEntity.created(location).build();
		} catch (Exception e) {
			return ResponseEntity.internalServerError().build();
		}
	}

	@GetMapping("allBooks")
	public ResponseEntity<List<Book>> getAllBooks() {
		try {
			List<Book> books = new ArrayList<Book>();
			bookRepository.findAll().forEach(books::add);

			if (books.isEmpty()) {
				return ResponseEntity.noContent().build();
			}
			return ResponseEntity.ok(books);
		} catch (Exception e) {
			return ResponseEntity.internalServerError().build();
		}
	}

	@DeleteMapping("removeBook1/{bookId}")
	public ResponseEntity<Boolean> deleteBook(@PathVariable("bookId") int bookId) {
		try {
			bookRepository.removeByBookId(bookId);
			return ResponseEntity.ok(true);
		} catch (Exception e) {
			return ResponseEntity.notFound().build();
		}
	}

	@Transactional
	@PutMapping("updateBook/{bookId}")
	public ResponseEntity<Boolean> updateBook(@PathVariable("bookId") int bookId, @RequestBody Book book) {
		Optional<Book> bookData = bookRepository.findByBookId(bookId);
		if (bookData.isPresent()) {
			Book _book = bookData.get();
			_book.setBookId(book.getBookId());
			_book.setBookName(book.getBookName());
			_book.setBookAuthor(book.getBookAuthor());
			bookRepository.save(_book);
			return ResponseEntity.ok(true);
		} else {
			return ResponseEntity.notFound().build();
		}
	}

}
