package com.rishi.springboot.firstDemo.webController;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;



import com.rishi.springboot.firstDemo.dao.EmpDao;
import com.rishi.springboot.firstDemo.model.Employee;



@Controller
public class EmpController {



   @Autowired
    EmpDao EmpDao;
    
    @GetMapping("getEmp/{EmpId}")
    public String getEmpDetails(@PathVariable int EmpId, ModelMap model) {
        Employee e =this.EmpDao.getEmp(EmpId);
        
        System.out.println("here");



       if(e != null) {
            model.addAttribute("Employee", e);
            
        } else {
            model.addAttribute("message", "Employee not found, EmpId = " + EmpId);
        }
        return "Emp";
    }
}