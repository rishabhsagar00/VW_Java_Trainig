package com.rishi.springboot.firstDemo.model;



public class Employee {




    private String EmpName;
    private int EmpId;
    private String deptName;
    private int Designation;



   public Employee() {
        System.out.println("Employee bean created...");
    }
    
    public Employee(int EmpId, String EmpName, String deptName, int Designation) {
        super();
        this.EmpName = EmpName;
        this.EmpId = EmpId;
        this.deptName = deptName;
        this.Designation = Designation;
    }



   public String getEmpName() {
        return EmpName;
    }



   public void setEmpName(String EmpName) {
        this.EmpName = EmpName;
    }



   public int getEmpId() {
        return EmpId;
    }



   public void setEmpId(int bookId) {
        this.EmpId = EmpId;
    }



   public String getdeptName() {
        return deptName;
    }



   public void setdeptName(String deptName) {
        this.deptName = deptName;
    }



   public int getDesignation() {
        return Designation;
    }



   public void setDesignation(int Designation) {
        this.Designation = Designation;
    }



   @Override
    public String toString() {
        return "Emp [EmpName=" + EmpName + ", EmpId=" + EmpId + ", deptName=" + deptName + ", Designation="
                + Designation + "]";
    }



   @Override
    public boolean equals(Object obj) {
        return ((Employee)obj).EmpId == this.EmpId;
    }



}