package com.rishi.springboot.firstDemo.dao;



import java.util.ArrayList;




import java.util.List;




import org.springframework.stereotype.Service;
import com.rishi.springboot.firstDemo.model.Employee;



@Service
public class EmpDao {



   List<Employee> EmpArr;



   public EmpDao() {
        EmpArr = new ArrayList<Employee>();



       EmpArr.add(new Employee(1, "piyush rawat","developer",200));
        EmpArr.add(new Employee(2, "Sandeep","tester", 345));
        EmpArr.add(new Employee(3, "rishabh","Analyst", 500));
        EmpArr.add(new Employee(4, "preetam","Hr", 560));
        EmpArr.add(new Employee(5, "vaibhav","manager", 340));
        
    }



   public boolean addEmp(Employee e) {
        this.EmpArr.add(e);
        return true;
    }



   public Employee getEmp(int EmpId) {
        Employee Emp = EmpArr.stream().filter((e) -> {
            return e.getEmpId() == EmpId;
        }).findFirst().orElse(null);
        System.out.println(Emp);
        return Emp;
    }




    public int removeEmp(Employee e) {
        boolean status = this.EmpArr.remove(e);
        if (status)
            return e.getEmpId();
        else
            return -1;
    }



   public int removeEmployee(int EmpId) {
        boolean status = this.EmpArr.removeIf(e -> e.getEmpId() == EmpId);
        if(status)
            return EmpId;
        else
            return -1;
    }



   public List<Employee> getAllEmp() {
        return this.EmpArr;
    }



}