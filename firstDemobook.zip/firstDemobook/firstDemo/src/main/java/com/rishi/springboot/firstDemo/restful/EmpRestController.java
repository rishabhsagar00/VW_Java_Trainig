package com.rishi.springboot.firstDemo.restful;



import java.net.URI;
import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;



import com.rishi.springboot.firstDemo.dao.BookDao;
import com.rishi.springboot.firstDemo.dao.EmpDao;
import com.rishi.springboot.firstDemo.exceptions.BookNotFoundException;
import com.rishi.springboot.firstDemo.exceptions.EmpNotFoundException;
import com.rishi.springboot.firstDemo.model.Book;
import com.rishi.springboot.firstDemo.model.Employee;



@RestController
public class EmpRestController {



   @Autowired
    EmpDao EmpDao;



   @GetMapping("Emp/{EmpId}")
    public Employee getEmp(@PathVariable int EmpId) {
        Employee e = this.EmpDao.getEmp(EmpId);
        if (e == null)
            throw new EmpNotFoundException("Employee with id:" + EmpId + " not found");
        else
            return e;
    }



   @GetMapping("Emp1/{EmpId}")
    public ResponseEntity<Employee> getEmp1(@PathVariable int EmpId) {
        Employee e = this.EmpDao.getEmp(EmpId);
        if (e== null)
            return ResponseEntity.notFound().build();
        else
            return ResponseEntity.ok(e);



   }



   @PostMapping("addEmp")
    public String addEmp(@RequestBody Employee e) {
        boolean r = this.EmpDao.addEmp(e);
        if (r) {
            return "Employee with EmpId: " + e.getEmpId() + " added successfully";
        } else {
            return "Employee not added, EmpId: " + e.getEmpId();
        }
    }



   @PostMapping("addEmp1")
    public ResponseEntity<Employee> addEmp1(@RequestBody Employee e) {
        boolean r = this.EmpDao.addEmp(e);
        if (!r) {
            return ResponseEntity.noContent().build();
        }
        URI location = ServletUriComponentsBuilder.fromCurrentContextPath().path("/Emp/{id}")
                .buildAndExpand(e.getEmpId()).toUri();
        return ResponseEntity.created(location).build();
    }



   @GetMapping("allEmp")
    public List<Employee> getAllEmp() {
        return this.EmpDao.getAllEmp();
    }



   @DeleteMapping("removeEmp")
    public String removeEmp(@RequestBody Employee e) {
        int EmpId = this.EmpDao.removeEmp(e);
        if (EmpId != -1) {
            return "Employee with EmpId = " + EmpId + " deleted successfully";
        } else {
            return "-1";
        }
    }



   @DeleteMapping("removeEmp1/{EmpId}")
    public String removeEmp1(@PathVariable int EmpId) {
        int _EmpId = this.EmpDao.removeEmployee(EmpId);
        if (_EmpId != -1) {
            return "Emp with EmpId = " + _EmpId + " deleted successfully";
        } else {
            return "-1";
        }
    }



   
}