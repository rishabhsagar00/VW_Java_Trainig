package Exception;



public class ZeroBalanceException extends Exception {
    
    @Override
    public String toString()
    {
        return "Sorry, You have Zero Balance in Your Account!";
    }
    
}