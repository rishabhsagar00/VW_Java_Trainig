package JDBC_operation;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import AccountController.Account;
import Exception.InsufficientBalanceException;
import Exception.ZeroBalanceException;



public class AccountDao {



   List<Account> accountList = new ArrayList<Account>();
    Connection con;
    Statement st;
    PreparedStatement psmt;



   
    
    public AccountDao() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }



   public void create(Account a) throws SQLException {
        
        //Connection
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/account", "root", "Rishabh@1234");
        st = con.createStatement();
        
        
        //Query
        String s = "insert into account_details values (?, ?);";
        psmt = con.prepareStatement(s);
        psmt.setLong(1, a.getAcctId());
        psmt.setDouble(2, a.getBal());
        psmt.executeUpdate();
        accountList.add(a);
    }



   public void update(Long id, double balance) throws SQLException {
        
        //Connection
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/account", "root", "123456");
        st = con.createStatement();
        
        //Query
        String s = "update account_details set account_balance = ? where account_number = ?;";
        psmt = con.prepareStatement(s);
        psmt.setLong(1, id);
        psmt.setDouble(2, balance);
        psmt.executeUpdate();
    }



   public void withdraw(int accountNumber, int amount) throws SQLException, InsufficientBalanceException, ZeroBalanceException {
        String fetch = "select * from account_details where account_number = ?";
        psmt = con.prepareStatement(fetch);
        psmt.setInt(1, accountNumber);
        ResultSet rs = psmt.executeQuery();
        int balance = 0;
        while(rs.next()) {
            balance = rs.getInt(3);
        }



       if (balance > amount) {
            String query = "update account_details set account_balance = account_balance - ? where account_number = ?;";
            psmt = con.prepareStatement(query);
            psmt.setInt(1, amount);
            psmt.setInt(2, accountNumber);
            psmt.executeUpdate();
        }
        else if(balance == amount){
            throw new ZeroBalanceException();
        }
    }



}