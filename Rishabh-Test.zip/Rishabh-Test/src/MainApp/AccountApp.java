package MainApp;



import java.sql.SQLException;
import java.util.Scanner;

import AccountController.Account;
import Exception.InsufficientBalanceException;
import Exception.ZeroBalanceException;
import JDBC_operation.AccountDao;




public class AccountApp {
    public static void main(String[] args) throws SQLException, InsufficientBalanceException, ZeroBalanceException {
        
        String yesno = "no";
        
        AccountDao acctDao = new AccountDao();
        
        acctDao.create(new Account(101 ,9000));
        
                
        



   }



}