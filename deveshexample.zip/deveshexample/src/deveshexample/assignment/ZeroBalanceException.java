package deveshexample.assignment;

public class ZeroBalanceException extends Exception {
	
	private int currBal;
	private int withAmt;
	private int acctno;
	
	
	public ZeroBalanceException(int currBal, int withAmt, int acctno) {
		super();
		this.currBal = currBal;
		this.withAmt = withAmt;
		this.acctno = acctno;
	}


	@Override
	public String toString() {
	
		return "ZeroBalanceException [currBal=" + currBal + ", withAmt=" + withAmt + ", acctno=" + acctno + "]";
	}

}
