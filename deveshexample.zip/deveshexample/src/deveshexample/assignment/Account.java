package deveshexample.assignment;

/*(Group A) Devesh Pratap Singh
Main-class -> AccountController (contained will have Account object )
. withdraw,deposit,getbalance                        
.userdefined exception � zero balance
AccountDAO layer -> JDBC operation*/

public class Account {
	
	private int accountNumber;
	private String name;
	private int accountBalance;
	
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Account(int accountNumber, String name, int accountBalance) {
		super();
		this.accountNumber = accountNumber;
		this.name = name;
		this.accountBalance = accountBalance;
	}

	public int getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAccountBalance() {
		return accountBalance;
	}

	public void setAccountBalance(int accountBalance) {
		this.accountBalance = accountBalance;
	}

	@Override
	public String toString() {
		return "Account [accountNumber=" + accountNumber + ", name=" + name + ", accountBalance=" + accountBalance
				+ "]";
	}
	
	

}
