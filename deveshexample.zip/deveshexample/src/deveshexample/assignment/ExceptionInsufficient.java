package deveshexample.assignment;

public class ExceptionInsufficient extends Exception{

	private int currBal;
	private int withAmt;
	private int acctno;
	
	
	public ExceptionInsufficient(int currBal, int withAmt, int acctno) {
		super();
		this.currBal = currBal;
		this.withAmt = withAmt;
		this.acctno = acctno;
	}


	@Override
	public String toString() {
	
		return "InsufficientBalanceException [currBal=" + currBal + ", withAmt=" + withAmt + ", acctno=" + acctno + "]";
	}
	
	
	
}
