package deveshexample.assignment;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class AccountDAO {

	List<Account> accountList = new ArrayList<Account>();
	Connection con;
	Statement st;
	PreparedStatement psmt;

	public AccountDAO() throws SQLException {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		con = DriverManager.getConnection("jdbc:mysql://localhost:3306/account", "root", "redhat");
		st = con.createStatement();
	}

	public void createAccount(Account acct) throws SQLException {
		String insertQuery = "INSERT INTO account_details values (?, ?, ?);";
		psmt = con.prepareStatement(insertQuery);
		psmt.setInt(1, acct.getAccountNumber());
		psmt.setString(2, acct.getName());
		psmt.setInt(3, acct.getAccountBalance());
		psmt.executeUpdate();
		accountList.add(acct);
	}

	public List<Account> getAccounts() throws SQLException {

		ResultSet rs = st.executeQuery("select * from account_details");
		while (rs.next()) {
			Account acc = new Account(rs.getInt(1), rs.getString(2), rs.getInt(3));
			accountList.add(acc);
		}

		return accountList;
	}

	public void updateAccount(int accountNumber, int newBalance) throws SQLException {
		String query = "update account_details set account_balance = ? where account_number = ?;";
		psmt = con.prepareStatement(query);
		psmt.setInt(1, newBalance);
		psmt.setInt(2, accountNumber);
		psmt.executeUpdate();
	}

	public void deleteAccount(int accountNumber) throws SQLException {
		String query = "DELETE FROM account_details where account_number=?";
		psmt = con.prepareStatement(query);
		psmt.setInt(1, accountNumber);
		int result = psmt.executeUpdate();
		System.out.println("Number of records affected :: " + result);
	}

	public void depositToAccount(int accountNumber, int amount) throws SQLException {
		String query = "update account_details set account_balance = account_balance + ? where account_number = ?;";
		psmt = con.prepareStatement(query);
		psmt.setInt(1, amount);
		psmt.setInt(2, accountNumber);
		psmt.executeUpdate();
	}

	public void withdrawFromAccount(int accountNumber, int amount) throws SQLException, ExceptionInsufficient, ZeroBalanceException {
		String fetch = "select * from account_details where account_number = ?";
		psmt = con.prepareStatement(fetch);
		psmt.setInt(1, accountNumber);
		ResultSet rs = psmt.executeQuery();
		int balance = 0;
		while(rs.next()) {
			balance = rs.getInt(3);
		}

		if (balance > amount) {
			String query = "update account_details set account_balance = account_balance - ? where account_number = ?;";
			psmt = con.prepareStatement(query);
			psmt.setInt(1, amount);
			psmt.setInt(2, accountNumber);
			psmt.executeUpdate();
		}
		else if(balance == amount){
			throw new ZeroBalanceException(balance, amount, accountNumber);
		}
		
		else  {
			throw new ExceptionInsufficient(balance,amount,accountNumber);
		}
	}

}
