package deveshexample.assignment;

import java.sql.SQLException;

public class AccountController {
	
	public static void main(String [] args) throws SQLException, ExceptionInsufficient, ZeroBalanceException {
		AccountDAO acctDao = new AccountDAO();
		acctDao.createAccount(new Account(101,"Joe",9000));
		acctDao.createAccount(new Account(102,"Tom",7000));
		acctDao.updateAccount(102, 500);
		acctDao.deleteAccount(101);
		acctDao.depositToAccount(102, 500);
		acctDao.withdrawFromAccount(102, 1500);
		System.out.println(acctDao.getAccounts());
	}
	
	

}
